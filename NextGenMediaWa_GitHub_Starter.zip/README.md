# NextGenMediaWa — GitHub Pages starter

This is a custom static website starter for NextGenMediaWa. It is not a Blogger theme and does not display Blogger branding.

## What is included
- Responsive news/media homepage in black, white and red
- Sections for Ghana News, Entertainment, Music, Sports and Trending
- Sample post data in `posts.json`
- Decap CMS admin interface scaffold in `/admin`
- CMS collection configuration for articles and music metadata

## Free hosting
GitHub Pages can host the public static website for free on an eligible public repository. The expected URL is:

`https://YOUR-GITHUB-USERNAME.github.io/nextgenmediawa/`

## Publish the website
1. Create or sign in to a GitHub account.
2. Create a **public** repository named `nextgenmediawa`.
3. Upload the contents of this folder to the repository root (not the enclosing folder).
4. In GitHub, open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Replace the placeholder GitHub username in `admin/config.yml` with your real GitHub username and repository name.

## Admin dashboard — important setup
The `/admin` area is a CMS interface scaffold, not a ready-to-login production dashboard yet. GitHub-backed CMS authentication needs a secure OAuth provider. Do **not** put a GitHub personal access token or OAuth client secret in browser JavaScript or in this public repository. Configure a trusted OAuth proxy (for example, a Cloudflare Worker with secrets stored as Worker secrets) and then set the Decap CMS `base_url` / `auth_endpoint` values according to that provider's instructions.

Until that OAuth step is completed, use GitHub's repository editor to update files. The CMS config is provided as a starting point and requires the repository and authentication details to be completed.

## Article publishing note
The homepage currently reads `posts.json`. The CMS configuration is set up to edit `posts.json` and `music.json`, which the homepage reads directly. The admin interface still needs a secure GitHub OAuth provider before it can sign in and save changes. Individual long-form article pages are not generated in this starter; the cards can link to article URLs you add.

## Music uploads
Do not use the GitHub repository as an unlimited music file host. Store audio on a suitable file-storage or audio-hosting service and paste its stream/download URLs into the music entry. Check the provider's free-tier limits, public access rules and copyright requirements. Only upload music you own or are authorized to distribute.

## Custom domain
A custom domain is optional and usually costs money to register. The `github.io` address is free.
